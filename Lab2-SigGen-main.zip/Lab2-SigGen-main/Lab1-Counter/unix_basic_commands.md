## 8 Most useful UNIX commands that you must learn
<br>

![Unix Commands](images/unix_basic_8.jpg)