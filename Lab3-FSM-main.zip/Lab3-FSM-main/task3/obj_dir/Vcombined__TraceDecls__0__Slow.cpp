// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Tracing declarations
#include "verilated_vcd_c.h"


void Vcombined___024root__traceDeclTypesSub0(VerilatedVcd* tracep) {
}

void Vcombined___024root__trace_decl_types(VerilatedVcd* tracep) {
    Vcombined___024root__traceDeclTypesSub0(tracep);
}
