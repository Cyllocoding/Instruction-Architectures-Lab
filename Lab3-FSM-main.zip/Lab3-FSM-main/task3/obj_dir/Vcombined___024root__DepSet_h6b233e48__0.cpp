// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vcombined.h for the primary calling header

#include "Vcombined__pch.h"
#include "Vcombined___024root.h"

void Vcombined___024root___eval_act(Vcombined___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vcombined___024root___eval_act\n"); );
    Vcombined__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

void Vcombined___024root___nba_sequent__TOP__0(Vcombined___024root* vlSelf);
void Vcombined___024root___nba_sequent__TOP__1(Vcombined___024root* vlSelf);
void Vcombined___024root___nba_sequent__TOP__2(Vcombined___024root* vlSelf);

void Vcombined___024root___eval_nba(Vcombined___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vcombined___024root___eval_nba\n"); );
    Vcombined__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1ULL & vlSelfRef.__VnbaTriggered.word(0U))) {
        Vcombined___024root___nba_sequent__TOP__0(vlSelf);
    }
    if ((3ULL & vlSelfRef.__VnbaTriggered.word(0U))) {
        Vcombined___024root___nba_sequent__TOP__1(vlSelf);
    }
    if ((1ULL & vlSelfRef.__VnbaTriggered.word(0U))) {
        Vcombined___024root___nba_sequent__TOP__2(vlSelf);
    }
}

VL_INLINE_OPT void Vcombined___024root___nba_sequent__TOP__0(Vcombined___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vcombined___024root___nba_sequent__TOP__0\n"); );
    Vcombined__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__Vdly__combined__DOT__clktick__DOT__count 
        = vlSelfRef.combined__DOT__clktick__DOT__count;
}

VL_INLINE_OPT void Vcombined___024root___nba_sequent__TOP__1(Vcombined___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vcombined___024root___nba_sequent__TOP__1\n"); );
    Vcombined__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.rst) {
        vlSelfRef.combined__DOT__lights__DOT__current_state = 0U;
    } else if (vlSelfRef.combined__DOT__flash) {
        vlSelfRef.combined__DOT__lights__DOT__current_state 
            = vlSelfRef.combined__DOT__lights__DOT__next_state;
    }
    if (((((((((0U == vlSelfRef.combined__DOT__lights__DOT__current_state) 
               | (1U == vlSelfRef.combined__DOT__lights__DOT__current_state)) 
              | (2U == vlSelfRef.combined__DOT__lights__DOT__current_state)) 
             | (3U == vlSelfRef.combined__DOT__lights__DOT__current_state)) 
            | (4U == vlSelfRef.combined__DOT__lights__DOT__current_state)) 
           | (5U == vlSelfRef.combined__DOT__lights__DOT__current_state)) 
          | (6U == vlSelfRef.combined__DOT__lights__DOT__current_state)) 
         | (7U == vlSelfRef.combined__DOT__lights__DOT__current_state))) {
        if ((0U == vlSelfRef.combined__DOT__lights__DOT__current_state)) {
            vlSelfRef.combined__DOT__lights__DOT__next_state = 1U;
            vlSelfRef.data_out = 0U;
        } else if ((1U == vlSelfRef.combined__DOT__lights__DOT__current_state)) {
            vlSelfRef.combined__DOT__lights__DOT__next_state = 2U;
            vlSelfRef.data_out = 1U;
        } else if ((2U == vlSelfRef.combined__DOT__lights__DOT__current_state)) {
            vlSelfRef.combined__DOT__lights__DOT__next_state = 3U;
            vlSelfRef.data_out = 3U;
        } else if ((3U == vlSelfRef.combined__DOT__lights__DOT__current_state)) {
            vlSelfRef.combined__DOT__lights__DOT__next_state = 4U;
            vlSelfRef.data_out = 7U;
        } else if ((4U == vlSelfRef.combined__DOT__lights__DOT__current_state)) {
            vlSelfRef.combined__DOT__lights__DOT__next_state = 5U;
            vlSelfRef.data_out = 0xfU;
        } else if ((5U == vlSelfRef.combined__DOT__lights__DOT__current_state)) {
            vlSelfRef.combined__DOT__lights__DOT__next_state = 6U;
            vlSelfRef.data_out = 0x1fU;
        } else if ((6U == vlSelfRef.combined__DOT__lights__DOT__current_state)) {
            vlSelfRef.combined__DOT__lights__DOT__next_state = 7U;
            vlSelfRef.data_out = 0x3fU;
        } else {
            vlSelfRef.combined__DOT__lights__DOT__next_state = 8U;
            vlSelfRef.data_out = 0x7fU;
        }
    } else if ((8U == vlSelfRef.combined__DOT__lights__DOT__current_state)) {
        vlSelfRef.combined__DOT__lights__DOT__next_state = 0U;
        vlSelfRef.data_out = 0xffU;
    }
}

VL_INLINE_OPT void Vcombined___024root___nba_sequent__TOP__2(Vcombined___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vcombined___024root___nba_sequent__TOP__2\n"); );
    Vcombined__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.rst) {
        vlSelfRef.combined__DOT__flash = 0U;
        vlSelfRef.__Vdly__combined__DOT__clktick__DOT__count 
            = vlSelfRef.N;
    } else if (vlSelfRef.en) {
        if ((0U == (IData)(vlSelfRef.combined__DOT__clktick__DOT__count))) {
            vlSelfRef.combined__DOT__flash = 1U;
            vlSelfRef.__Vdly__combined__DOT__clktick__DOT__count 
                = vlSelfRef.N;
        } else {
            vlSelfRef.__Vdly__combined__DOT__clktick__DOT__count 
                = (0xffffU & ((IData)(vlSelfRef.combined__DOT__clktick__DOT__count) 
                              - (IData)(1U)));
            vlSelfRef.combined__DOT__flash = 0U;
        }
    }
    vlSelfRef.combined__DOT__clktick__DOT__count = vlSelfRef.__Vdly__combined__DOT__clktick__DOT__count;
}

void Vcombined___024root___eval_triggers__act(Vcombined___024root* vlSelf);

bool Vcombined___024root___eval_phase__act(Vcombined___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vcombined___024root___eval_phase__act\n"); );
    Vcombined__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    VlTriggerVec<2> __VpreTriggered;
    CData/*0:0*/ __VactExecute;
    // Body
    Vcombined___024root___eval_triggers__act(vlSelf);
    __VactExecute = vlSelfRef.__VactTriggered.any();
    if (__VactExecute) {
        __VpreTriggered.andNot(vlSelfRef.__VactTriggered, vlSelfRef.__VnbaTriggered);
        vlSelfRef.__VnbaTriggered.thisOr(vlSelfRef.__VactTriggered);
        Vcombined___024root___eval_act(vlSelf);
    }
    return (__VactExecute);
}

bool Vcombined___024root___eval_phase__nba(Vcombined___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vcombined___024root___eval_phase__nba\n"); );
    Vcombined__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*0:0*/ __VnbaExecute;
    // Body
    __VnbaExecute = vlSelfRef.__VnbaTriggered.any();
    if (__VnbaExecute) {
        Vcombined___024root___eval_nba(vlSelf);
        vlSelfRef.__VnbaTriggered.clear();
    }
    return (__VnbaExecute);
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vcombined___024root___dump_triggers__nba(Vcombined___024root* vlSelf);
#endif  // VL_DEBUG
#ifdef VL_DEBUG
VL_ATTR_COLD void Vcombined___024root___dump_triggers__act(Vcombined___024root* vlSelf);
#endif  // VL_DEBUG

void Vcombined___024root___eval(Vcombined___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vcombined___024root___eval\n"); );
    Vcombined__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    IData/*31:0*/ __VnbaIterCount;
    CData/*0:0*/ __VnbaContinue;
    // Body
    __VnbaIterCount = 0U;
    __VnbaContinue = 1U;
    while (__VnbaContinue) {
        if (VL_UNLIKELY(((0x64U < __VnbaIterCount)))) {
#ifdef VL_DEBUG
            Vcombined___024root___dump_triggers__nba(vlSelf);
#endif
            VL_FATAL_MT("combined.sv", 1, "", "NBA region did not converge.");
        }
        __VnbaIterCount = ((IData)(1U) + __VnbaIterCount);
        __VnbaContinue = 0U;
        vlSelfRef.__VactIterCount = 0U;
        vlSelfRef.__VactContinue = 1U;
        while (vlSelfRef.__VactContinue) {
            if (VL_UNLIKELY(((0x64U < vlSelfRef.__VactIterCount)))) {
#ifdef VL_DEBUG
                Vcombined___024root___dump_triggers__act(vlSelf);
#endif
                VL_FATAL_MT("combined.sv", 1, "", "Active region did not converge.");
            }
            vlSelfRef.__VactIterCount = ((IData)(1U) 
                                         + vlSelfRef.__VactIterCount);
            vlSelfRef.__VactContinue = 0U;
            if (Vcombined___024root___eval_phase__act(vlSelf)) {
                vlSelfRef.__VactContinue = 1U;
            }
        }
        if (Vcombined___024root___eval_phase__nba(vlSelf)) {
            __VnbaContinue = 1U;
        }
    }
}

#ifdef VL_DEBUG
void Vcombined___024root___eval_debug_assertions(Vcombined___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vcombined___024root___eval_debug_assertions\n"); );
    Vcombined__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (VL_UNLIKELY(((vlSelfRef.en & 0xfeU)))) {
        Verilated::overWidthError("en");}
    if (VL_UNLIKELY(((vlSelfRef.rst & 0xfeU)))) {
        Verilated::overWidthError("rst");}
    if (VL_UNLIKELY(((vlSelfRef.clk & 0xfeU)))) {
        Verilated::overWidthError("clk");}
}
#endif  // VL_DEBUG
