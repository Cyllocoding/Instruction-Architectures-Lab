// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vcombined.h for the primary calling header

#include "Vcombined__pch.h"
#include "Vcombined__Syms.h"
#include "Vcombined___024root.h"

void Vcombined___024root___ctor_var_reset(Vcombined___024root* vlSelf);

Vcombined___024root::Vcombined___024root(Vcombined__Syms* symsp, const char* v__name)
    : VerilatedModule{v__name}
    , vlSymsp{symsp}
 {
    // Reset structure values
    Vcombined___024root___ctor_var_reset(this);
}

void Vcombined___024root::__Vconfigure(bool first) {
    (void)first;  // Prevent unused variable warning
}

Vcombined___024root::~Vcombined___024root() {
}
